using Microsoft.AspNetCore.Mvc;
using DevVulnApp.Models;
using System.Text.Encodings.Web;
using System;

namespace DevVulnApp.Controllers
{
    public class AuthentController : Controller
    {
        // 
        // GET: /Authent/
        public IActionResult Index() => View("Login");
        public IActionResult Registrate() => View("Registration");
        public IActionResult Login() => View("Login");
        public String LoginUser (UserModel u){
            //return u.GetUsername();
            return "Vous êtes bien connecter";
        }
        public String RegistrateUser (UserModel u){
            //return u.GetUsername();
            return "Vous êtes bien enregistrer";
        }
    }
}
