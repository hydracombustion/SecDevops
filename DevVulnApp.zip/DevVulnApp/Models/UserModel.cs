using System;
using System.ComponentModel.DataAnnotations;

namespace DevVulnApp.Models
{
    public class UserModel
    {
        [Required]
        public string Username { get; set; }
        [Required]
        public string Password { get; set; }
        [Required]
        public string Email { get; set; }
        public string GetUsername(){
            return this.Username;
        }
        public string GetMail(){
            return this.Email;
        }
        public string GetPassword(){
            return this.Password;
        }
    }
}
